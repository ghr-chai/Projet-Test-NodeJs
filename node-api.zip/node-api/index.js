//appeler le framework express
const express = require('express');
//appeler toutes les fonctions natives au framework express
const app = express();
//se connecter à notre serveur
app.listen(5500, ()=> console.log('Server started: 5500'));

btn.onclick = () => {

    const fs = require('fs');
    const data = JSON.parse( fs.readFileSync('lieux-de-tournage-a-paris.geojson', 'utf8') );
    
}